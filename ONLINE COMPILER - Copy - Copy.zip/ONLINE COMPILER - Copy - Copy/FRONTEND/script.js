const API_URL = 'http://localhost:5000/api';
let editor = null;
let token = localStorage.getItem('token');
let currentUser = null;
let lastAutoTemplate = null;
let hasUserEditedSinceTemplate = false;
let currentLang = 'c';

const drafts = {
  c: null,
  cpp: null
};

const TEMPLATES = {
  c: `#include <stdio.h>\n\nint main() {\n    printf("Hello, World!\\n");\n    return 0;\n}\n`,
  cpp: `#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n    cout << "Hello, World!" << \"\\n\";\n    return 0;\n}\n`
};

function setTemplateForLanguage(lang) {
  const template = TEMPLATES[lang] || '';
  editor.setValue(template);
  lastAutoTemplate = template;
  hasUserEditedSinceTemplate = false;
}

// Initialize CodeMirror
function initEditor() {
  editor = CodeMirror.fromTextArea(document.getElementById('codeEditor'), {
    mode: 'text/x-csrc',
    theme: 'dracula',
    lineNumbers: true,
    autoCloseBrackets: true,
    matchBrackets: true,
    indentUnit: 4,
    tabSize: 4,
    lineWrapping: true
  });
  editor.on('change', () => {
    const current = editor.getValue();
    if (lastAutoTemplate !== null && current !== lastAutoTemplate) {
      hasUserEditedSinceTemplate = true;
    }
  });

  currentLang = document.getElementById('languageSelect').value || 'c';
  setTemplateForLanguage(currentLang);
  updateEditorMode();
}

function updateEditorMode() {
  const lang = document.getElementById('languageSelect').value;
  const mode = lang === 'c' ? 'text/x-csrc' : 'text/x-c++src';
  editor.setOption('mode', mode);

  // Save current buffer as a draft for the old language.
  if (currentLang) {
    drafts[currentLang] = editor.getValue();
  }

  // Load draft for the new language (or a fresh template if none yet).
  const next = drafts[lang];
  if (typeof next === 'string' && next.trim() !== '') {
    editor.setValue(next);
    lastAutoTemplate = null;
    hasUserEditedSinceTemplate = true;
  } else {
    setTemplateForLanguage(lang);
  }

  currentLang = lang;
}

// Auth UI
function updateAuthUI() {
  const token = localStorage.getItem('token');
  if (token) {
    document.getElementById('loginBtn').style.display = 'none';
    document.getElementById('registerBtn').style.display = 'none';
    document.getElementById('logoutBtn').style.display = 'inline-block';
    document.getElementById('userDisplay').style.display = 'inline';
    // decode username from JWT (simplified)
    const payload = JSON.parse(atob(token.split('.')[1]));
    currentUser = payload.user;
    document.getElementById('userDisplay').innerText = `👋 ${currentUser?.username || 'User'}`;
  } else {
    document.getElementById('loginBtn').style.display = 'inline-block';
    document.getElementById('registerBtn').style.display = 'inline-block';
    document.getElementById('logoutBtn').style.display = 'none';
    document.getElementById('userDisplay').style.display = 'none';
    currentUser = null;
  }
}

// Modal handling
const authModal = document.getElementById('authModal');
const snippetsModal = document.getElementById('snippetsModal');
let authMode = 'login';

function openAuthModal(mode) {
  authMode = mode;
  document.getElementById('modalTitle').innerText = mode === 'login' ? 'Login' : 'Register';
  document.getElementById('authUsername').style.display = mode === 'register' ? 'block' : 'none';
  document.getElementById('authEmail').value = '';
  document.getElementById('authPassword').value = '';
  document.getElementById('authUsername').value = '';
  document.getElementById('authError').innerText = '';
  authModal.style.display = 'block';
}

async function submitAuth() {
  const email = document.getElementById('authEmail').value;
  const password = document.getElementById('authPassword').value;
  const username = document.getElementById('authUsername').value;
  const endpoint = authMode === 'login' ? '/auth/login' : '/auth/register';
  const body = authMode === 'login' ? { email, password } : { username, email, password };

  try {
    const res = await fetch(`${API_URL}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('token', data.token);
    token = data.token;
    updateAuthUI();
    authModal.style.display = 'none';
    alert(`${authMode === 'login' ? 'Logged in' : 'Registered'} successfully!`);
  } catch (err) {
    document.getElementById('authError').innerText = err.message;
  }
}

function logout() {
  localStorage.removeItem('token');
  token = null;
  updateAuthUI();
  alert('Logged out');
}

// Compile code
async function runCode() {
  if (!token) {
    alert('Please login first');
    return;
  }
  const code = editor.getValue();
  const language = document.getElementById('languageSelect').value;
  const stdin = document.getElementById('stdin') ? document.getElementById('stdin').value : '';
  const outputElem = document.getElementById('output');
  outputElem.innerText = '⏳ Compiling & running...';

  try {
    const res = await fetch(`${API_URL}/compile`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': token
      },
      body: JSON.stringify({ code, language, stdin })
    });
    const data = await res.json();

    // Backend may return either:
    // - { error: true, output: "..." }
    // - { error: "some message" } (older shape)
    const isError =
      data?.error === true ||
      (typeof data?.error === 'string' && data.error.trim() !== '');

    if (isError) {
      const msg =
        (typeof data?.output === 'string' && data.output.trim() !== '' && data.output) ||
        (typeof data?.error === 'string' && data.error.trim() !== '' && data.error) ||
        'Unknown error';
      outputElem.innerText = `❌ Error:\n${msg}`;
    } else {
      outputElem.innerText = data.output || '(no output)';
    }
  } catch (err) {
    outputElem.innerText = `Network error: ${err.message}`;
  }
}

// Save current code
async function saveCode() {
  if (!token) { alert('Login required'); return; }
  const title = prompt('Enter a title for this snippet:', 'My Code');
  if (!title) return;
  const language = document.getElementById('languageSelect').value;
  const code = editor.getValue();
  try {
    const res = await fetch(`${API_URL}/code/save`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': token
      },
      body: JSON.stringify({ title, language, code })
    });
    const data = await res.json();
    if (res.ok) alert('Code saved!');
    else alert('Save failed: ' + data.error);
  } catch (err) {
    alert('Error saving');
  }
}

// Load snippets list
async function showSnippets() {
  if (!token) { alert('Login required'); return; }
  try {
    const res = await fetch(`${API_URL}/code/list`, {
      headers: { 'x-auth-token': token }
    });
    const snippets = await res.json();
    const listElem = document.getElementById('snippetsList');
    listElem.innerHTML = '';
    if (snippets.length === 0) {
      listElem.innerHTML = '<li>No saved snippets</li>';
    } else {
      snippets.forEach(snip => {
        const li = document.createElement('li');
        li.className = 'snippet-item';

        const meta = document.createElement('div');
        meta.className = 'snippet-meta';
        meta.innerText = `${snip.title} (${snip.language.toUpperCase()}) - ${new Date(snip.createdAt).toLocaleString()}`;
        meta.onclick = () => loadSnippetById(snip._id);

        const actions = document.createElement('div');
        actions.className = 'snippet-actions';

        const delBtn = document.createElement('button');
        delBtn.className = 'snippet-delete';
        delBtn.type = 'button';
        delBtn.innerText = 'Delete';
        delBtn.onclick = async (e) => {
          e.stopPropagation();
          const ok = confirm(`Delete snippet "${snip.title}"?`);
          if (!ok) return;
          await deleteSnippetById(snip._id);
          await showSnippets();
        };

        actions.appendChild(delBtn);
        li.appendChild(meta);
        li.appendChild(actions);
        listElem.appendChild(li);
      });
    }
    snippetsModal.style.display = 'block';
  } catch (err) {
    alert('Failed to load snippets');
  }
}

async function deleteSnippetById(id) {
  const res = await fetch(`${API_URL}/code/${id}`, {
    method: 'DELETE',
    headers: { 'x-auth-token': token }
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to delete snippet');
  }
}

async function loadSnippetById(id) {
  try {
    const res = await fetch(`${API_URL}/code/${id}`, {
      headers: { 'x-auth-token': token }
    });
    const snippet = await res.json();
    if (res.ok) {
      editor.setValue(snippet.code);
      document.getElementById('languageSelect').value = snippet.language;
      updateEditorMode();
      snippetsModal.style.display = 'none';
      alert(`Loaded: ${snippet.title}`);
    } else {
      alert('Could not load snippet');
    }
  } catch (err) {
    alert('Error loading snippet');
  }
}

// Event listeners
document.getElementById('loginBtn').onclick = () => openAuthModal('login');
document.getElementById('registerBtn').onclick = () => openAuthModal('register');
document.getElementById('logoutBtn').onclick = logout;
document.getElementById('submitAuthBtn').onclick = submitAuth;
document.getElementById('runBtn').onclick = runCode;
document.getElementById('saveBtn').onclick = saveCode;
document.getElementById('loadBtn').onclick = showSnippets;
document.querySelector('#authModal .close').onclick = () => authModal.style.display = 'none';
document.querySelector('#snippetsModal .close-snippets').onclick = () => snippetsModal.style.display = 'none';
window.onclick = (e) => {
  if (e.target === authModal) authModal.style.display = 'none';
  if (e.target === snippetsModal) snippetsModal.style.display = 'none';
};
document.getElementById('languageSelect').onchange = updateEditorMode;

// Initialize
initEditor();
updateAuthUI();