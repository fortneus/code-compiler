// backend/utils/customCompiler.js
// Lexical, Syntax, Semantic Analysis + Interpreter for mini-C

// ---------- LEXER (Lexical Analysis) ----------
class Token {
  constructor(type, value, line) {
    this.type = type;   // 'KEYWORD', 'IDENTIFIER', 'NUMBER', 'OPERATOR', 'PUNCTUATION', 'STRING'
    this.value = value;
    this.line = line;
  }
}

const keywords = new Set(['int', 'if', 'else', 'while', 'for', 'return', 'printf', 'scanf', 'break']);
const operators = new Set(['+', '-', '*', '/', '%', '=', '<', '>', '<=', '>=', '==', '!=', '++', '--', '&']);
const punctuation = new Set([';', ',', '(', ')', '{', '}']);

function unescapeCString(s) {
  return s.replace(/\\(n|t|r|\\|"|0)/g, (_, esc) => {
    switch (esc) {
      case 'n': return '\n';
      case 't': return '\t';
      case 'r': return '\r';
      case '\\': return '\\';
      case '"': return '"';
      case '0': return '\0';
      default: return esc;
    }
  });
}

function tokenize(code) {
  const tokens = [];
  let i = 0;
  let line = 1;
  const len = code.length;

  while (i < len) {
    let ch = code[i];

    // Skip whitespace
    if (/\s/.test(ch)) {
      if (ch === '\n') line++;
      i++;
      continue;
    }

    // Skip preprocessor directives like: #include <stdio.h>
    if (ch === '#') {
      while (i < len && code[i] !== '\n') i++;
      continue;
    }

    // Skip single-line comments
    if (ch === '/' && code[i+1] === '/') {
      while (i < len && code[i] !== '\n') i++;
      continue;
    }

    // Skip multi-line comments
    if (ch === '/' && code[i+1] === '*') {
      i += 2;
      while (i < len && !(code[i-1] === '*' && code[i] === '/')) {
        if (code[i] === '\n') line++;
        i++;
      }
      i++;
      continue;
    }

    // Identifiers and keywords
    if (/[a-zA-Z_]/.test(ch)) {
      let start = i;
      while (i < len && /[a-zA-Z0-9_]/.test(code[i])) i++;
      const word = code.slice(start, i);
      const type = keywords.has(word) ? 'KEYWORD' : 'IDENTIFIER';
      tokens.push(new Token(type, word, line));
      continue;
    }

    // Numbers
    if (/[0-9]/.test(ch)) {
      let start = i;
      while (i < len && /[0-9]/.test(code[i])) i++;
      const num = code.slice(start, i);
      tokens.push(new Token('NUMBER', parseInt(num, 10), line));
      continue;
    }

    // String literals (for printf)
    if (ch === '"') {
      i++; // skip opening quote
      let raw = '';
      while (i < len) {
        if (code[i] === '\n') line++;
        if (code[i] === '"') break;
        if (code[i] === '\\' && i + 1 < len) {
          raw += code[i] + code[i + 1];
          i += 2;
          continue;
        }
        raw += code[i];
        i++;
      }
      if (i >= len) throw new Error(`Unclosed string at line ${line}`);
      tokens.push(new Token('STRING', unescapeCString(raw), line));
      i++;
      continue;
    }

    // Operators (including multi-char)
    let op = ch;
    if (i + 1 < len && (code.slice(i, i + 2) === '++' || code.slice(i, i + 2) === '--')) {
      op = code.slice(i, i + 2);
      i++;
    } else if (i+1 < len && ['<', '>', '=', '!'].includes(ch) && code[i+1] === '=') {
      op += code[i+1];
      i++;
    }
    if (operators.has(op)) {
      tokens.push(new Token('OPERATOR', op, line));
      i++;
      continue;
    }

    // Punctuation
    if (punctuation.has(ch)) {
      tokens.push(new Token('PUNCTUATION', ch, line));
      i++;
      continue;
    }

    throw new Error(`Unexpected character '${ch}' at line ${line}`);
  }
  return tokens;
}

// ---------- PARSER (Syntax Analysis) ----------
class ASTNode {
  constructor(type, ...args) {
    this.type = type;
    if (args.length) Object.assign(this, ...args);
  }
}

class Parser {
  constructor(tokens) {
    this.tokens = tokens;
    this.pos = 0;
  }

  peek() { return this.tokens[this.pos]; }
  peekN(n) { return this.tokens[this.pos + n]; }
  peekIs(type, value) {
    const tok = this.peek();
    if (!tok) return false;
    if (tok.type !== type) return false;
    if (value === undefined) return true;
    return tok.value === value;
  }
  consume(type, value) {
    const tok = this.peek();
    if (!tok) throw new Error('Unexpected end of input');
    if (tok.type !== type || (value !== undefined && tok.value !== value)) {
      throw new Error(`Expected ${type} ${value || ''} at line ${tok.line}`);
    }
    this.pos++;
    return tok;
  }

  match(type, value) {
    const tok = this.peek();
    if (tok && tok.type === type && (value === undefined || tok.value === value)) {
      this.pos++;
      return true;
    }
    return false;
  }

  parseProgram() {
    const functions = [];
    const statements = [];
    while (this.peek()) {
      const tok = this.peek();
      const t1 = this.peekN(1);
      const t2 = this.peekN(2);
      if (
        tok &&
        tok.type === 'KEYWORD' &&
        tok.value === 'int' &&
        t1 &&
        t1.type === 'IDENTIFIER' &&
        t2 &&
        t2.type === 'PUNCTUATION' &&
        t2.value === '('
      ) {
        functions.push(this.parseFunction());
        continue;
      }
      statements.push(this.parseStatement());
    }
    return new ASTNode('Program', { functions, statements });
  }

  parseFunction() {
    this.consume('KEYWORD', 'int');
    const name = this.consume('IDENTIFIER').value;
    this.consume('PUNCTUATION', '(');
    this.consume('PUNCTUATION', ')');
    const body = this.parseBlock();
    return new ASTNode('Function', { name, body });
  }

  parseStatement() {
    const tok = this.peek();
    if (tok.type === 'PUNCTUATION' && tok.value === '{') {
      return this.parseBlock();
    }
    if (tok.type === 'KEYWORD') {
      switch (tok.value) {
        case 'int': return this.parseDeclaration();
        case 'if': return this.parseIf();
        case 'while': return this.parseWhile();
        case 'for': return this.parseFor();
        case 'break': return this.parseBreak();
        case 'return': return this.parseReturn();
        case 'printf': return this.parsePrintf();
        case 'scanf': return this.parseScanf();
      }
    }
    // expression statement (assignment or function call)
    const expr = this.parseExpression();
    this.consume('PUNCTUATION', ';');
    return new ASTNode('ExprStmt', { expression: expr });
  }

  parseDeclaration() {
    this.consume('KEYWORD', 'int');
    const decls = [];
    while (true) {
      const id = this.consume('IDENTIFIER').value;
      let init = null;
      if (this.match('OPERATOR', '=')) {
        init = this.parseExpression();
      }
      decls.push({ name: id, init });
      if (!this.match('PUNCTUATION', ',')) break;
    }
    this.consume('PUNCTUATION', ';');
    if (decls.length === 1) return new ASTNode('Declaration', decls[0]);
    return new ASTNode('MultiDecl', { decls });
  }

  parseBreak() {
    this.consume('KEYWORD', 'break');
    this.consume('PUNCTUATION', ';');
    return new ASTNode('Break');
  }

  parseScanf() {
    this.consume('KEYWORD', 'scanf');
    this.consume('PUNCTUATION', '(');
    const format = this.consume('STRING').value;
    const targets = [];

    if (this.match('PUNCTUATION', ',')) {
      while (true) {
        // support: &n
        if (this.match('OPERATOR', '&')) {
          // ignore address-of, we just want the identifier name
        }
        const id = this.consume('IDENTIFIER').value;
        targets.push(id);
        if (!this.match('PUNCTUATION', ',')) break;
      }
    }

    this.consume('PUNCTUATION', ')');
    this.consume('PUNCTUATION', ';');
    return new ASTNode('Scanf', { format, targets });
  }

  parseBlock() {
    this.consume('PUNCTUATION', '{');
    const statements = [];
    while (this.peek() && !(this.peek().type === 'PUNCTUATION' && this.peek().value === '}')) {
      statements.push(this.parseStatement());
    }
    this.consume('PUNCTUATION', '}');
    return new ASTNode('Block', { statements });
  }

  parseIf() {
    this.consume('KEYWORD', 'if');
    this.consume('PUNCTUATION', '(');
    const condition = this.parseExpression();
    this.consume('PUNCTUATION', ')');
    const thenStmt = this.parseStatement();
    let elseStmt = null;
    if (this.match('KEYWORD', 'else')) {
      elseStmt = this.parseStatement();
    }
    return new ASTNode('If', { condition, thenStmt, elseStmt });
  }

  parseWhile() {
    this.consume('KEYWORD', 'while');
    this.consume('PUNCTUATION', '(');
    const condition = this.parseExpression();
    this.consume('PUNCTUATION', ')');
    const body = this.parseStatement();
    return new ASTNode('While', { condition, body });
  }

  parseFor() {
    this.consume('KEYWORD', 'for');
    this.consume('PUNCTUATION', '(');

    // init
    let init = null;
    if (!(this.peek().type === 'PUNCTUATION' && this.peek().value === ';')) {
      if (this.peek().type === 'KEYWORD' && this.peek().value === 'int') {
        init = this.parseForDeclaration();
      } else {
        init = this.parseExpression();
      }
    }
    this.consume('PUNCTUATION', ';');

    // condition
    let condition = null;
    if (!(this.peek().type === 'PUNCTUATION' && this.peek().value === ';')) {
      condition = this.parseExpression();
    }
    this.consume('PUNCTUATION', ';');

    // update
    let update = null;
    if (!(this.peek().type === 'PUNCTUATION' && this.peek().value === ')')) {
      update = this.parseExpression();
    }
    this.consume('PUNCTUATION', ')');

    const body = this.parseStatement();
    return new ASTNode('For', { init, condition, update, body });
  }

  parseForDeclaration() {
    this.consume('KEYWORD', 'int');
    const id = this.consume('IDENTIFIER').value;
    let init = null;
    if (this.match('OPERATOR', '=')) {
      init = this.parseExpression();
    }
    return new ASTNode('Declaration', { name: id, init });
  }

  parseReturn() {
    this.consume('KEYWORD', 'return');
    const expr = this.parseExpression();
    this.consume('PUNCTUATION', ';');
    return new ASTNode('Return', { value: expr });
  }

  parsePrintf() {
    this.consume('KEYWORD', 'printf');
    this.consume('PUNCTUATION', '(');
    const format = this.consume('STRING').value;
    let args = [];
    if (this.match('PUNCTUATION', ',')) {
      args.push(this.parseExpression());
      while (this.match('PUNCTUATION', ',')) {
        args.push(this.parseExpression());
      }
    }
    this.consume('PUNCTUATION', ')');
    this.consume('PUNCTUATION', ';');
    return new ASTNode('Printf', { format, args });
  }

  parseExpression() {
    return this.parseAssignment();
  }

  parseAssignment() {
    let left = this.parseComparison();
    if (this.match('OPERATOR', '=')) {
      const right = this.parseAssignment();
      if (left.type !== 'Identifier')
        throw new Error('Left side of assignment must be a variable');
      return new ASTNode('Assign', { left: left.name, right });
    }
    return left;
  }

  parseComparison() {
    let left = this.parseAdditive();
    while (this.peekIs('OPERATOR') && ['<', '>', '<=', '>=', '==', '!='].includes(this.peek().value)) {
      const op = this.consume('OPERATOR').value;
      const right = this.parseAdditive();
      left = new ASTNode('BinaryOp', { op, left, right });
    }
    return left;
  }

  parseAdditive() {
    let left = this.parseMultiplicative();
    while (this.peekIs('OPERATOR') && (this.peek().value === '+' || this.peek().value === '-')) {
      const op = this.consume('OPERATOR').value;
      const right = this.parseMultiplicative();
      left = new ASTNode('BinaryOp', { op, left, right });
    }
    return left;
  }

  parseMultiplicative() {
    let left = this.parsePrimary();
    while (this.peekIs('OPERATOR') && (this.peek().value === '*' || this.peek().value === '/' || this.peek().value === '%')) {
      const op = this.consume('OPERATOR').value;
      const right = this.parsePrimary();
      left = new ASTNode('BinaryOp', { op, left, right });
    }
    return left;
  }

  parsePrimary() {
    const tok = this.peek();
    if (tok.type === 'NUMBER') {
      this.pos++;
      return new ASTNode('Number', { value: tok.value });
    }
    if (tok.type === 'IDENTIFIER') {
      this.pos++;
      const idNode = new ASTNode('Identifier', { name: tok.value });

      // Function call like: sqrt(n)
      if (this.peek() && this.peek().type === 'PUNCTUATION' && this.peek().value === '(') {
        this.consume('PUNCTUATION', '(');
        const args = [];
        if (!(this.peek().type === 'PUNCTUATION' && this.peek().value === ')')) {
          args.push(this.parseExpression());
          while (this.match('PUNCTUATION', ',')) {
            args.push(this.parseExpression());
          }
        }
        this.consume('PUNCTUATION', ')');
        return new ASTNode('Call', { name: idNode.name, args });
      }

      if (this.peek() && this.peek().type === 'OPERATOR' && (this.peek().value === '++' || this.peek().value === '--')) {
        const op = this.consume('OPERATOR').value;
        return new ASTNode('PostfixUpdate', { op, name: idNode.name });
      }
      return idNode;
    }
    if (tok.type === 'PUNCTUATION' && tok.value === '(') {
      this.consume('PUNCTUATION', '(');
      const expr = this.parseExpression();
      this.consume('PUNCTUATION', ')');
      return expr;
    }
    throw new Error(`Unexpected token at line ${tok.line}: ${tok.value}`);
  }
}

// ---------- SEMANTIC ANALYSIS (Symbol Table & Type Checking) ----------
class SymbolTable {
  constructor(parent = null) {
    this.symbols = new Map();
    this.parent = parent;
  }
  declare(name, type) {
    if (this.symbols.has(name)) throw new Error(`Variable '${name}' already declared`);
    this.symbols.set(name, { type });
  }
  lookup(name) {
    if (this.symbols.has(name)) return this.symbols.get(name);
    if (this.parent) return this.parent.lookup(name);
    throw new Error(`Variable '${name}' not declared`);
  }
}

function semanticAnalysis(ast) {
  const globalTable = new SymbolTable();

  const functions = new Map();
  for (const fn of ast.functions || []) {
    if (functions.has(fn.name)) throw new Error(`Function '${fn.name}' already defined`);
    functions.set(fn.name, fn);
  }
  if (functions.size > 0 && !functions.has('main')) {
    throw new Error("Missing entry point: define 'int main() { ... }'");
  }

  function visit(node, table) {
    if (node.type === 'Program') {
      for (const stmt of node.statements || []) visit(stmt, table);
      for (const fn of node.functions || []) visit(fn, table);
    } else if (node.type === 'Function') {
      const fnTable = new SymbolTable(table);
      visit(node.body, fnTable);
    } else if (node.type === 'Block') {
      const blockTable = new SymbolTable(table);
      for (const stmt of node.statements) visit(stmt, blockTable);
    } else if (node.type === 'Declaration') {
      table.declare(node.name, 'int');
      if (node.init) visit(node.init, table);
    } else if (node.type === 'MultiDecl') {
      for (const d of node.decls) {
        table.declare(d.name, 'int');
        if (d.init) visit(d.init, table);
      }
    } else if (node.type === 'Assign') {
      const varInfo = table.lookup(node.left);
      if (varInfo.type !== 'int') throw new Error(`Type mismatch: ${node.left} is not int`);
      visit(node.right, table);
    } else if (node.type === 'BinaryOp') {
      visit(node.left, table);
      visit(node.right, table);
    } else if (node.type === 'Number') {
      // ok
    } else if (node.type === 'Identifier') {
      table.lookup(node.name);
    } else if (node.type === 'If') {
      visit(node.condition, table);
      visit(node.thenStmt, table);
      if (node.elseStmt) visit(node.elseStmt, table);
    } else if (node.type === 'While') {
      visit(node.condition, table);
      visit(node.body, table);
    } else if (node.type === 'Return') {
      if (node.value) visit(node.value, table);
    } else if (node.type === 'Printf') {
      for (const arg of node.args) visit(arg, table);
    } else if (node.type === 'Scanf') {
      for (const t of node.targets) table.lookup(t);
    } else if (node.type === 'For') {
      const loopTable = new SymbolTable(table);
      if (node.init) visit(node.init, loopTable);
      if (node.condition) visit(node.condition, loopTable);
      if (node.update) visit(node.update, loopTable);
      visit(node.body, loopTable);
    } else if (node.type === 'ExprStmt') {
      visit(node.expression, table);
    } else if (node.type === 'PostfixUpdate') {
      table.lookup(node.name);
    } else if (node.type === 'Call') {
      for (const arg of node.args) visit(arg, table);
    } else if (node.type === 'Break') {
      // ok
    } else {
      throw new Error(`Unknown AST node: ${node.type}`);
    }
  }
  visit(ast, globalTable);
  return true;
}

// ---------- INTERPRETER (Execution) ----------
class Env {
  constructor(parent = null) {
    this.parent = parent;
    this.values = new Map();
  }
  has(name) {
    if (this.values.has(name)) return true;
    return this.parent ? this.parent.has(name) : false;
  }
  get(name) {
    if (this.values.has(name)) return this.values.get(name);
    if (this.parent) return this.parent.get(name);
    throw new Error(`Undefined variable ${name}`);
  }
  declare(name, value) {
    if (this.values.has(name)) throw new Error(`Variable '${name}' already declared`);
    this.values.set(name, value);
  }
  set(name, value) {
    if (this.values.has(name)) {
      this.values.set(name, value);
      return;
    }
    if (this.parent && this.parent.has(name)) {
      this.parent.set(name, value);
      return;
    }
    this.values.set(name, value);
  }
}

class BreakException extends Error {}

class Interpreter {
  constructor(stdin = '') {
    this.global = new Env(null);
    this.outputChunks = [];
    this.functions = new Map();
    this.input = String(stdin ?? '').split(/\s+/).filter(Boolean);
  }

  evaluate(node, env = this.global) {
    switch (node.type) {
      case 'Program':
        for (const fn of node.functions || []) this.functions.set(fn.name, fn);
        if (this.functions.has('main')) {
          this.evaluate(this.functions.get('main'), env);
          return null;
        }
        for (const stmt of node.statements || []) this.evaluate(stmt, env);
        return null;
      case 'Function': {
        const fnEnv = new Env(env);
        try {
          this.evaluate(node.body, fnEnv);
          return 0;
        } catch (e) {
          if (e instanceof ReturnException) return e.value;
          throw e;
        }
      }
      case 'Block': {
        const blockEnv = new Env(env);
        for (const stmt of node.statements) this.evaluate(stmt, blockEnv);
        return null;
      }
      case 'Declaration':
        let val = 0;
        if (node.init) val = this.evaluate(node.init, env);
        env.declare(node.name, val);
        return null;
      case 'MultiDecl':
        for (const d of node.decls) {
          let v = 0;
          if (d.init) v = this.evaluate(d.init, env);
          env.declare(d.name, v);
        }
        return null;
      case 'Assign':
        const rightVal = this.evaluate(node.right, env);
        env.set(node.left, rightVal);
        return rightVal;
      case 'BinaryOp':
        const left = this.evaluate(node.left, env);
        const right = this.evaluate(node.right, env);
        switch (node.op) {
          case '+': return left + right;
          case '-': return left - right;
          case '*': return left * right;
          case '/': return Math.floor(left / right);
          case '%': return left % right;
          case '<': return left < right ? 1 : 0;
          case '>': return left > right ? 1 : 0;
          case '<=': return left <= right ? 1 : 0;
          case '>=': return left >= right ? 1 : 0;
          case '==': return left === right ? 1 : 0;
          case '!=': return left !== right ? 1 : 0;
          default: throw new Error(`Unknown operator ${node.op}`);
        }
      case 'Number':
        return node.value;
      case 'Identifier':
        return env.get(node.name);
      case 'If':
        const cond = this.evaluate(node.condition, env);
        if (cond !== 0) this.evaluate(node.thenStmt, env);
        else if (node.elseStmt) this.evaluate(node.elseStmt, env);
        return null;
      case 'While':
        while (this.evaluate(node.condition, env) !== 0) {
          this.evaluate(node.body, env);
        }
        return null;
      case 'For': {
        const loopEnv = new Env(env);
        if (node.init) this.evaluate(node.init, loopEnv);
        while (node.condition ? this.evaluate(node.condition, loopEnv) !== 0 : true) {
          try {
            this.evaluate(node.body, loopEnv);
          } catch (e) {
            if (e instanceof BreakException) break;
            throw e;
          }
          if (node.update) this.evaluate(node.update, loopEnv);
        }
        return null;
      }
      case 'Break':
        throw new BreakException();
      case 'Return':
        const retVal = node.value ? this.evaluate(node.value, env) : 0;
        throw new ReturnException(retVal);
      case 'PostfixUpdate': {
        const current = env.get(node.name);
        if (node.op === '++') {
          env.set(node.name, current + 1);
          return current;
        }
        if (node.op === '--') {
          env.set(node.name, current - 1);
          return current;
        }
        throw new Error(`Unknown update operator ${node.op}`);
      }
      case 'Printf':
        // simplistic: extract format string and replace %d with arguments
        let fmt = node.format;
        let argIdx = 0;
        let result = fmt.replace(/%d/g, () => {
          if (argIdx >= node.args.length) return '?';
          return this.evaluate(node.args[argIdx++], env);
        });
        this.outputChunks.push(String(result));
        return null;
      case 'Scanf': {
        // Very small subset: supports reading integers via %d.
        for (const name of node.targets) {
          const next = this.input.length ? this.input.shift() : undefined;
          const num = next === undefined ? 0 : parseInt(next, 10);
          env.set(name, Number.isFinite(num) ? num : 0);
        }
        return null;
      }
      case 'Call': {
        const args = node.args.map((a) => this.evaluate(a, env));
        if (node.name === 'sqrt') {
          const x = args[0] ?? 0;
          return Math.floor(Math.sqrt(x));
        }
        throw new Error(`Unknown function ${node.name}`);
      }
      case 'ExprStmt':
        return this.evaluate(node.expression, env);
      default:
        throw new Error(`Unknown node type ${node.type}`);
    }
  }

  run(ast) {
    try {
      this.evaluate(ast);
      return { output: this.outputChunks.join(''), error: false };
    } catch (e) {
      if (e instanceof ReturnException) {
        return { output: this.outputChunks.join(''), error: false, returnValue: e.value };
      }
      return { output: e.message, error: true };
    }
  }
}

class ReturnException extends Error {
  constructor(value) { super(); this.value = value; }
}

// ---------- MAIN COMPILER FUNCTION ----------
function compileAndRunCustom(code, language, stdin = '') {
  try {
    // Lexical analysis
    const tokens = tokenize(code);
    // Syntax analysis
    const parser = new Parser(tokens);
    const ast = parser.parseProgram();
    // Semantic analysis
    semanticAnalysis(ast);
    // Interpretation (execution)
    const interpreter = new Interpreter(stdin);
    const result = interpreter.run(ast);
    return result;
  } catch (err) {
    return { output: `Error: ${err.message}`, error: true };
  }
}

module.exports = { compileAndRunCustom };