const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

function runProcess(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      ...options,
      windowsHide: true
    });

    let stdout = '';
    let stderr = '';

    if (child.stdout) child.stdout.on('data', (d) => (stdout += d.toString()));
    if (child.stderr) child.stderr.on('data', (d) => (stderr += d.toString()));

    child.on('error', reject);
    child.on('close', (code, signal) => resolve({ code, signal, stdout, stderr }));
  });
}

async function compileAndRunNative(code, language) {
  const tmpRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'online-compiler-'));
  const ext = language === 'c' ? 'c' : 'cpp';
  const compiler = language === 'c' ? 'gcc' : 'g++';
  const sourcePath = path.join(tmpRoot, `main.${ext}`);
  const exePath = path.join(tmpRoot, process.platform === 'win32' ? 'a.exe' : 'a.out');

  try {
    await fs.writeFile(sourcePath, code, 'utf8');

    // Compile
    const compileRes = await runProcess(
      compiler,
      [sourcePath, '-O2', '-std=c11', '-o', exePath],
      { cwd: tmpRoot, timeout: 10000 }
    );

    if (compileRes.code !== 0) {
      return { output: compileRes.stderr || compileRes.stdout || 'Compilation failed', error: true };
    }

    // Run
    const runRes = await runProcess(exePath, [], { cwd: tmpRoot, timeout: 3000 });

    if (runRes.signal) {
      return { output: `Program terminated (${runRes.signal})\n${runRes.stderr || runRes.stdout}`, error: true };
    }

    if (runRes.code !== 0) {
      return { output: runRes.stderr || runRes.stdout || `Program exited with code ${runRes.code}`, error: true };
    }

    return { output: runRes.stdout, error: false };
  } catch (err) {
    // Common on Windows: gcc/g++ not installed (MinGW/MSYS2).
    const msg = (err && err.message) ? err.message : String(err);
    return {
      output:
        `Server couldn't compile/run with ${compiler}.\n` +
        `Reason: ${msg}\n\n` +
        `Fix (Windows): install MinGW-w64 or MSYS2 and ensure '${compiler}' is in PATH.`,
      error: true
    };
  } finally {
    try {
      await fs.rm(tmpRoot, { recursive: true, force: true });
    } catch {
      // ignore cleanup errors
    }
  }
}

module.exports = { compileAndRunNative };

