const { compileAndRunCustom } = require('./UTILS/compilerdesign');

const code = `#include <stdio.h>
#include <math.h> // Required for sqrt()

int main() {
    int n, isPrime = 1;
    scanf("%d", &n);

    if (n <= 1) {
        isPrime = 0;
    } else {
        for (int i = 2; i <= sqrt(n); i++) {
            if (n % i == 0) {
                isPrime = 0;
                break;
            }
        }
    }

    if (isPrime == 1) {
        printf("prime\\n");
    } else {
        printf("not prime\\n");
    }

    return 0;
}
`;

console.log(compileAndRunCustom(code, 'c', '10'));

