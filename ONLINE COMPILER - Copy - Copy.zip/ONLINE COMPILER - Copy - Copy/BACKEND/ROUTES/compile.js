const express = require('express');
const router = express.Router();
const auth = require('../MIDDLEWARE/auth');
const { compileAndRunCustom } = require('../UTILS/compilerdesign');
const rateLimit = require('express-rate-limit');

const compileLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: 'Too many compile requests, please wait' }
});

router.post('/', [auth, compileLimiter], async (req, res) => {
  try {
    const { code, language, stdin } = req.body;
    if (!code || !['c', 'cpp'].includes(language)) {
      return res.status(400).json({ error: true, output: 'Invalid code or language' });
    }
    const result = compileAndRunCustom(code, language, stdin);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: true,
      output: process.env.NODE_ENV === 'development'
        ? `Compilation server error: ${err?.message || err}`
        : 'Compilation server error'
    });
  }
});

module.exports = router;