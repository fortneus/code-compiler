const express = require('express');
const router = express.Router();
const auth = require('../MIDDLEWARE/auth');
const CodeSnippet = require('../MODELS/codesnippet');

// Save code
router.post('/save', auth, async (req, res) => {
  try {
    const { title, language, code } = req.body;
    const snippet = new CodeSnippet({
      userId: req.user.id,
      title: title || 'Untitled',
      language,
      code
    });
    await snippet.save();
    res.json({ id: snippet._id, message: 'Saved successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save code' });
  }
});

// Load user's saved snippets
router.get('/list', auth, async (req, res) => {
  try {
    const snippets = await CodeSnippet.find({ userId: req.user.id })
      .sort({ updatedAt: -1 })
      .select('title language createdAt _id');
    res.json(snippets);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load snippets' });
  }
});

// Load a specific snippet
router.get('/:id', auth, async (req, res) => {
  try {
    const snippet = await CodeSnippet.findOne({ _id: req.params.id, userId: req.user.id });
    if (!snippet) return res.status(404).json({ error: 'Not found' });
    res.json(snippet);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load snippet' });
  }
});

// Delete a specific snippet
router.delete('/:id', auth, async (req, res) => {
  try {
    const deleted = await CodeSnippet.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    if (!deleted) return res.status(404).json({ error: 'Not found' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete snippet' });
  }
});

module.exports = router;